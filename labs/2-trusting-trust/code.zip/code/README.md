What to do:
 1.  Do the steps in order: step1, step2, step3.  `make check` in
     each directory should pass.
 2.  Doing a final `make check` in this directory should work pass.
