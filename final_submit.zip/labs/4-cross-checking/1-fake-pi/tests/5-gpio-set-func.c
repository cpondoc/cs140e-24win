#include "rpi.h"
void notmain(void) {
    gpio_set_function(20, 3);
}
