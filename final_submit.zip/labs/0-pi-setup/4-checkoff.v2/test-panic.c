#include "rpi.h"

void notmain(void) {
    panic("checking that panic works: should die\n");
}
