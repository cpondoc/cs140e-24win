#include "rpi.h"

void notmain(void) {
    int pin = 20;
    trace("has interrupt = %d\n", gpio_has_interrupt());
    trace("has interrupt = %d\n", gpio_has_interrupt());
    trace("has interrupt = %d\n", gpio_has_interrupt());
    trace("has interrupt = %d\n", gpio_has_interrupt());
    trace("has interrupt = %d\n", gpio_has_interrupt());
}
