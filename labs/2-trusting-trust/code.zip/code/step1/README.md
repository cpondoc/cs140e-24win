### What to do

As described in the lab README:
  1.  Finish implementing `quine-gen.c`.
  2. `make check` should pass.
