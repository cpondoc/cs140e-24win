#include "rpi.h"
void notmain(void) {
    uart_init();
}
