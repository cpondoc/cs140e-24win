### What to do

From the lab README.
  0. `make` should pass before you modify anything.  
     `make check` should fail (you have to implement
     the code so it passes).
  1. Implement the two attacks `trojan-compiler.c`
  2. `make check` should now pass.
