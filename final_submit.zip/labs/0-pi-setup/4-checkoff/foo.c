#include "rpi.h"
#include "foo.h"

void foo(void) {
    debug("in foo\n");
}
